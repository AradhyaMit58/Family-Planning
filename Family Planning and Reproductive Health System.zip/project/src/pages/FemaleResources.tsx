import React, { useState } from 'react';
import { Calendar, Play, Info, FileText, Calculator, Heart } from 'lucide-react';

interface CycleData {
  lastPeriod: string;
  cycleLength: number;
  symptoms: string[];
}

interface BudgetItem {
  category: string;
  amount: number;
}

const whoResources = [
  {
    title: "Family Planning",
    link: "https://www.who.int/health-topics/contraception",
    description: "WHO guidelines on contraception and family planning"
  },
  {
    title: "Reproductive Health",
    link: "https://www.who.int/health-topics/sexual-and-reproductive-health",
    description: "WHO resources on reproductive and sexual health"
  },
  {
    title: "Maternal Health",
    link: "https://www.who.int/health-topics/maternal-health",
    description: "WHO guidance on maternal health and pregnancy"
  }
];

const educationalVideos = [
  {
    title: "Understanding Your Menstrual Cycle",
    link: "https://youtu.be/WOi2Bwvp6hw",
    duration: "4:23"
  },
  {
    title: "Fertility Awareness Methods",
    link: "https://youtu.be/TZxn4r-zqIg",
    duration: "5:17"
  },
  {
    title: "Natural Family Planning",
    link: "https://youtu.be/TZxn4r-zqIg",
    duration: "6:45"
  }
];

const commonSymptoms = [
  'Cramps',
  'Headache',
  'Bloating',
  'Mood changes',
  'Breast tenderness',
  'Fatigue'
];

const budgetCategories = [
  'Prenatal vitamins',
  'Medical checkups',
  'Maternity wear',
  'Baby essentials',
  'Healthcare costs'
];

const topics = [
  {
    title: 'Fertility Awareness',
    content: [
      'Menstrual cycle tracking',
      'Ovulation monitoring',
      'Fertility signs and symptoms',
      'Natural family planning methods'
    ]
  },
  {
    title: 'Contraception Options',
    content: [
      'Hormonal birth control methods',
      'Non-hormonal alternatives',
      'Emergency contraception',
      'Long-term birth control options'
    ]
  },
  {
    title: 'Reproductive Health',
    content: [
      'Regular health screenings',
      'Pregnancy planning',
      'STI prevention and testing',
      'Reproductive health maintenance'
    ]
  },
  {
    title: 'Pregnancy Resources',
    content: [
      'Pre-pregnancy health',
      'Nutrition guidelines',
      'Exercise recommendations',
      'Prenatal care basics'
    ]
  }
];

export default function FemaleResources() {
  const [cycleData, setCycleData] = useState<CycleData>({
    lastPeriod: '',
    cycleLength: 28,
    symptoms: []
  });
  const [budget, setBudget] = useState<BudgetItem[]>(
    budgetCategories.map(category => ({ category, amount: 0 }))
  );

  const calculateFertileWindow = () => {
    if (!cycleData.lastPeriod) return null;
    
    const lastPeriod = new Date(cycleData.lastPeriod);
    const ovulationDay = new Date(lastPeriod);
    ovulationDay.setDate(lastPeriod.getDate() + cycleData.cycleLength - 14);
    
    const fertileStart = new Date(ovulationDay);
    fertileStart.setDate(ovulationDay.getDate() - 5);
    
    const fertileEnd = new Date(ovulationDay);
    fertileEnd.setDate(ovulationDay.getDate() + 1);
    
    return {
      ovulation: ovulationDay.toLocaleDateString(),
      fertileWindow: `${fertileStart.toLocaleDateString()} - ${fertileEnd.toLocaleDateString()}`
    };
  };

  const toggleSymptom = (symptom: string) => {
    setCycleData(prev => ({
      ...prev,
      symptoms: prev.symptoms.includes(symptom)
        ? prev.symptoms.filter(s => s !== symptom)
        : [...prev.symptoms, symptom]
    }));
  };

  const updateBudget = (category: string, amount: number) => {
    setBudget(prev =>
      prev.map(item =>
        item.category === category ? { ...item, amount } : item
      )
    );
  };

  const totalBudget = budget.reduce((sum, item) => sum + item.amount, 0);
  const fertileWindow = calculateFertileWindow();

  return (
    <div className="py-12 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <h1 className="text-3xl font-bold text-gray-900 mb-8">Women's Health Resources</h1>
        
        {/* Fertility Tracker */}
        <div className="bg-white p-6 rounded-lg shadow-md mb-8">
          <h2 className="text-2xl font-semibold text-gray-900 mb-4 flex items-center">
            <Calendar className="mr-2 text-teal-600" />
            Fertility Cycle Tracker
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                First Day of Last Period
              </label>
              <input
                type="date"
                value={cycleData.lastPeriod}
                onChange={(e) => setCycleData(prev => ({ ...prev, lastPeriod: e.target.value }))}
                className="w-full rounded-md border-gray-300 shadow-sm focus:border-teal-500 focus:ring-teal-500"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Average Cycle Length (days)
              </label>
              <input
                type="number"
                value={cycleData.cycleLength}
                onChange={(e) => setCycleData(prev => ({ ...prev, cycleLength: parseInt(e.target.value) }))}
                min="21"
                max="35"
                className="w-full rounded-md border-gray-300 shadow-sm focus:border-teal-500 focus:ring-teal-500"
              />
            </div>
          </div>

          {/* Symptom Tracker */}
          <div className="mt-6">
            <h3 className="text-lg font-medium text-gray-900 mb-3">Track Your Symptoms</h3>
            <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
              {commonSymptoms.map(symptom => (
                <button
                  key={symptom}
                  onClick={() => toggleSymptom(symptom)}
                  className={`p-2 rounded-md text-sm ${
                    cycleData.symptoms.includes(symptom)
                      ? 'bg-teal-100 text-teal-800 border-teal-200'
                      : 'bg-gray-50 text-gray-600 border-gray-200'
                  } border`}
                >
                  {symptom}
                </button>
              ))}
            </div>
          </div>
          
          {fertileWindow && (
            <div className="mt-6 p-4 bg-teal-50 rounded-md">
              <h3 className="font-semibold text-teal-900">Fertility Window Estimate</h3>
              <p className="text-teal-800 mt-2">Estimated Ovulation: {fertileWindow.ovulation}</p>
              <p className="text-teal-800">Fertile Window: {fertileWindow.fertileWindow}</p>
              <p className="text-sm text-teal-600 mt-2">
                Note: This is an estimate. For accurate family planning, consult with healthcare professionals.
              </p>
            </div>
          )}
        </div>

        {/* Family Planning Budget */}
        <div className="bg-white p-6 rounded-lg shadow-md mb-8">
          <h2 className="text-2xl font-semibold text-gray-900 mb-4 flex items-center">
            <Calculator className="mr-2 text-teal-600" />
            Family Planning Budget
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {budget.map(item => (
              <div key={item.category}>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  {item.category}
                </label>
                <input
                  type="number"
                  value={item.amount}
                  onChange={(e) => updateBudget(item.category, Number(e.target.value))}
                  className="w-full rounded-md border-gray-300 shadow-sm focus:border-teal-500 focus:ring-teal-500"
                  placeholder="Enter amount"
                  min="0"
                />
              </div>
            ))}
          </div>
          <div className="mt-6 p-4 bg-teal-50 rounded-md">
            <p className="text-teal-800 font-semibold">Total Budget: ${totalBudget}</p>
          </div>
        </div>

        {/* WHO Resources */}
        <div className="bg-white p-6 rounded-lg shadow-md mb-8">
          <h2 className="text-2xl font-semibold text-gray-900 mb-4 flex items-center">
            <Info className="mr-2 text-teal-600" />
            WHO Resources
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {whoResources.map((resource) => (
              <a
                key={resource.title}
                href={resource.link}
                target="_blank"
                rel="noopener noreferrer"
                className="block p-4 border border-gray-200 rounded-lg hover:bg-gray-50 transition-colors"
              >
                <h3 className="font-semibold text-teal-600">{resource.title}</h3>
                <p className="text-sm text-gray-600 mt-2">{resource.description}</p>
              </a>
            ))}
          </div>
        </div>

        {/* Educational Videos */}
        <div className="bg-white p-6 rounded-lg shadow-md mb-8">
          <h2 className="text-2xl font-semibold text-gray-900 mb-4 flex items-center">
            <Play className="mr-2 text-teal-600" />
            Educational Videos
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {educationalVideos.map((video) => (
              <a
                key={video.title}
                href={video.link}
                target="_blank"
                rel="noopener noreferrer"
                className="block p-4 border border-gray-200 rounded-lg hover:bg-gray-50 transition-colors"
              >
                <h3 className="font-semibold text-teal-600">{video.title}</h3>
                <p className="text-sm text-gray-600 mt-2">Duration: {video.duration}</p>
              </a>
            ))}
          </div>
        </div>

        {/* Health Topics */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {topics.map((topic) => (
            <div key={topic.title} className="bg-white p-6 rounded-lg shadow-md">
              <h2 className="text-xl font-semibold text-gray-900 mb-4">{topic.title}</h2>
              <ul className="space-y-2">
                {topic.content.map((item) => (
                  <li key={item} className="text-gray-600 flex items-start">
                    <span className="text-teal-600 mr-2">•</span>
                    {item}
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}