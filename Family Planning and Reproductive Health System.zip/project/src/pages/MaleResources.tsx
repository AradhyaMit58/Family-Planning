import React from 'react';

const topics = [
  {
    title: 'Male Fertility',
    content: [
      'Understanding sperm health and production',
      'Lifestyle factors affecting fertility',
      'Age-related fertility changes',
      'Fertility testing options'
    ]
  },
  {
    title: 'Contraception Options',
    content: [
      'Vasectomy information',
      'Condom types and proper usage',
      'Hormonal options for men',
      'Natural family planning methods'
    ]
  },
  {
    title: 'Reproductive Health',
    content: [
      'Regular health screenings',
      'STI prevention and testing',
      'Prostate health',
      'Sexual health maintenance'
    ]
  }
];

export default function MaleResources() {
  return (
    <div className="py-12 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <h1 className="text-3xl font-bold text-gray-900 mb-8">Men's Health Resources</h1>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {topics.map((topic) => (
            <div key={topic.title} className="bg-white p-6 rounded-lg shadow-md">
              <h2 className="text-xl font-semibold text-gray-900 mb-4">{topic.title}</h2>
              <ul className="space-y-2">
                {topic.content.map((item) => (
                  <li key={item} className="text-gray-600 flex items-start">
                    <span className="text-teal-600 mr-2">•</span>
                    {item}
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}