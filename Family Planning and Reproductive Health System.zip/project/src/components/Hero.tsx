import React from 'react';
import { Heart } from 'lucide-react';

export default function Hero() {
  return (
    <div className="relative bg-teal-50">
      <div className="max-w-7xl mx-auto px-4 py-16 sm:py-24">
        <div className="text-center">
          <Heart className="h-12 w-12 text-teal-600 mx-auto mb-4" />
          <h1 className="text-4xl font-bold text-gray-900 sm:text-5xl md:text-6xl">
            <span className="block">Empowering Families</span>
            <span className="block text-teal-600">Planning for Tomorrow</span>
          </h1>
          <p className="mt-3 max-w-md mx-auto text-base text-gray-500 sm:text-lg md:mt-5 md:text-xl md:max-w-3xl">
            Access comprehensive family planning resources, educational materials, and
            personalized guidance for making informed reproductive health decisions.
          </p>
          <div className="mt-5 max-w-md mx-auto sm:flex sm:justify-center md:mt-8">
            <div className="rounded-md shadow">
              <a href="#resources" className="w-full flex items-center justify-center px-8 py-3 border border-transparent text-base font-medium rounded-md text-white bg-teal-600 hover:bg-teal-700 md:py-4 md:text-lg md:px-10">
                Get Started
              </a>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}