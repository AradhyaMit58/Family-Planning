import React from 'react';
import { Heart, Calendar, Book, Users, Menu } from 'lucide-react';
import { Link } from 'react-router-dom';

export default function Navbar() {
  return (
    <nav className="bg-teal-600 text-white">
      <div className="max-w-7xl mx-auto px-4">
        <div className="flex justify-between items-center h-16">
          <Link to="/" className="flex items-center space-x-2">
            <Heart className="h-6 w-6" />
            <span className="font-semibold text-lg">FamilyCare</span>
          </Link>
          
          <div className="hidden md:flex space-x-8">
            <Link to="/resources" className="flex items-center space-x-1 hover:text-teal-200">
              <Book className="h-4 w-4" />
              <span>Resources</span>
            </Link>
            <a href="#planning" className="flex items-center space-x-1 hover:text-teal-200">
              <Calendar className="h-4 w-4" />
              <span>Family Planning</span>
            </a>
            <a href="#education" className="flex items-center space-x-1 hover:text-teal-200">
              <Users className="h-4 w-4" />
              <span>Education</span>
            </a>
          </div>
          
          <button className="md:hidden">
            <Menu className="h-6 w-6" />
          </button>
        </div>
      </div>
    </nav>
  );
}